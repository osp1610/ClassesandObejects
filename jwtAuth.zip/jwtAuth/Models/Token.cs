﻿namespace jwtAuth.Models
{
    public class Token
    {
        public string token { get; set; }
    }
}